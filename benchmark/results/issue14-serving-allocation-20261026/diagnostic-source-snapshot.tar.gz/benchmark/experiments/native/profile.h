// Diagnostic phase counters; never compiled into the primary timing extension.
#pragma once
#include <array>
#include <atomic>
#include <chrono>
#include <vector>
namespace experiment_profile {
enum Stage { preparation, scan, selection, merge, tables, count };
inline std::array<std::atomic<double>, count> seconds{};
inline std::atomic<bool> enabled{false};
inline void reset() { for (auto& x:seconds) x.store(0); enabled.store(true); }
inline std::vector<double> read() {
  enabled.store(false);
  std::vector<double> result;
  for (auto& x:seconds) result.push_back(x.load());
  return result;
}
class Phase {
  using Clock=std::chrono::steady_clock;
  Stage stage_;
  bool active_;
  Clock::time_point start_;
 public:
  explicit Phase(Stage stage):stage_(stage),active_(enabled.load()),start_(active_ ? Clock::now() : Clock::time_point{}) {}
  void stop() {
    if (!active_) return;
    seconds[stage_].fetch_add(std::chrono::duration<double>(Clock::now()-start_).count());
    active_=false;
  }
  ~Phase() { stop(); }
};
}
