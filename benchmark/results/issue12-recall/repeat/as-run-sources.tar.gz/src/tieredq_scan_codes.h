// Lossless byte-code fast scans retain FP32 codebook scores for high-precision models.
#pragma once
#include "tieredq_scan_int8.h"

namespace dv::tieredq_detail {
constexpr size_t fast_code_query_tile=4;
inline float fast_code_score(const FastScanCache& cache,const TieredQQuery& query,size_t doc) {
  float dot=0;
  for (size_t rank=0;rank<cache.dimensions;++rank) {
    const auto code=uint8_t(cache.levels[fast_level_position(cache.groups,doc,rank)]);
    dot+=query.weights[rank]*cache.codebooks[cache.tier_of[rank]][code];
  }
  const size_t cid=cache.centroid[doc];
  float score=query.centroid_scores[cid];
  score+=query.correction_weights[cid]*cache.correction[doc];
  score+=cache.factor[doc]*dot;
  return score;
}
} // namespace dv::tieredq_detail
