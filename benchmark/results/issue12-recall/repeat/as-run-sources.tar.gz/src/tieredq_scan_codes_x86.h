// SIMD gathers over byte code IDs avoid requantizing either codebooks or query weights.
#pragma once
#include "tieredq_scan_codes.h"
#include <immintrin.h>

namespace dv::tieredq_detail {
template<class QueryAt>
__attribute__((target("avx512f,avx512bw")))
inline void scan_codes_avx512_tile(const FastScanCache& cache,size_t rows,
    size_t first,size_t count,float* scores,size_t stride,QueryAt query) {
  if (rows>fast_code_query_tile) throw std::runtime_error("TieredQ: code query tile exceeds capacity");
  constexpr size_t lanes=16;
  for (size_t doc=first;doc<first+count;doc+=lanes) {
    __m512 dots[fast_code_query_tile];
    for (size_t row=0;row<rows;++row) dots[row]=_mm512_setzero_ps();
    for (size_t rank=0;rank<cache.dimensions;++rank) {
      const size_t block_first=doc/fast_scan_block_docs*fast_scan_block_docs;
      const auto* codes=cache.levels.data()+fast_level_position(cache.groups,block_first,rank-rank%fast_scan_coordinates_per_group);
      const auto packed=_mm512_loadu_si512(codes);
      const auto code=_mm512_and_si512(_mm512_srlv_epi32(packed,_mm512_set1_epi32(rank%fast_scan_coordinates_per_group*fast_scan_code_bits)),_mm512_set1_epi32(UINT8_MAX));
      const auto levels=_mm512_i32gather_ps(code,cache.codebooks[cache.tier_of[rank]].data(),sizeof(float));
      for (size_t row=0;row<rows;++row)
        dots[row]=_mm512_add_ps(dots[row],_mm512_mul_ps(levels,_mm512_set1_ps(query(row).weights[rank])));
    }
    const auto cid=_mm512_cvtepu8_epi32(_mm_loadu_si128(reinterpret_cast<const __m128i*>(cache.centroid.data()+doc)));
    for (size_t row=0;row<rows;++row) {
      const auto& q=query(row);
      auto score=_mm512_i32gather_ps(cid,q.centroid_scores.data(),sizeof(float));
      score=_mm512_add_ps(score,_mm512_mul_ps(_mm512_i32gather_ps(cid,q.correction_weights.data(),sizeof(float)),
          _mm512_loadu_ps(cache.correction.data()+doc)));
      score=_mm512_add_ps(score,_mm512_mul_ps(_mm512_loadu_ps(cache.factor.data()+doc),dots[row]));
      const size_t remaining=std::min(lanes,first+count-doc);
      _mm512_mask_storeu_ps(scores+row*stride+doc-first,__mmask16((1u<<remaining)-1),score);
    }
  }
}
template<class QueryAt>
__attribute__((target("avx2")))
inline void scan_codes_avx2_tile(const FastScanCache& cache,size_t rows,
    size_t first,size_t count,float* scores,size_t stride,QueryAt query) {
  if (rows>fast_code_query_tile) throw std::runtime_error("TieredQ: code query tile exceeds capacity");
  constexpr size_t lanes=8;
  for (size_t doc=first;doc<first+count;doc+=lanes) {
    __m256 dots[fast_code_query_tile];
    for (size_t row=0;row<rows;++row) dots[row]=_mm256_setzero_ps();
    for (size_t rank=0;rank<cache.dimensions;++rank) {
      const auto* codes=cache.levels.data()+fast_level_position(cache.groups,doc,rank-rank%fast_scan_coordinates_per_group);
      const auto packed=_mm256_loadu_si256(reinterpret_cast<const __m256i*>(codes));
      const auto code=_mm256_and_si256(_mm256_srlv_epi32(packed,_mm256_set1_epi32(rank%fast_scan_coordinates_per_group*fast_scan_code_bits)),_mm256_set1_epi32(UINT8_MAX));
      const auto levels=_mm256_i32gather_ps(cache.codebooks[cache.tier_of[rank]].data(),code,sizeof(float));
      for (size_t row=0;row<rows;++row)
        dots[row]=_mm256_add_ps(dots[row],_mm256_mul_ps(levels,_mm256_set1_ps(query(row).weights[rank])));
    }
    const auto cid=_mm256_cvtepu8_epi32(_mm_loadl_epi64(reinterpret_cast<const __m128i*>(cache.centroid.data()+doc)));
    for (size_t row=0;row<rows;++row) {
      const auto& q=query(row);
      auto score=_mm256_i32gather_ps(q.centroid_scores.data(),cid,sizeof(float));
      score=_mm256_add_ps(score,_mm256_mul_ps(_mm256_i32gather_ps(q.correction_weights.data(),cid,sizeof(float)),
          _mm256_loadu_ps(cache.correction.data()+doc)));
      score=_mm256_add_ps(score,_mm256_mul_ps(_mm256_loadu_ps(cache.factor.data()+doc),dots[row]));
      alignas(32) float tail[lanes];
      _mm256_store_ps(tail,score);
      std::copy_n(tail,std::min(lanes,first+count-doc),scores+row*stride+doc-first);
    }
  }
}
inline void scan_codes_avx512(const FastScanCache& cache,const TieredQQuery& q,
    size_t first,size_t count,float* scores) {
  scan_codes_avx512_tile(cache,1,first,count,scores,count,[&](size_t)->const TieredQQuery& {return q;});
}
inline void scan_codes_avx2(const FastScanCache& cache,const TieredQQuery& q,
    size_t first,size_t count,float* scores) {
  scan_codes_avx2_tile(cache,1,first,count,scores,count,[&](size_t)->const TieredQQuery& {return q;});
}
} // namespace dv::tieredq_detail
