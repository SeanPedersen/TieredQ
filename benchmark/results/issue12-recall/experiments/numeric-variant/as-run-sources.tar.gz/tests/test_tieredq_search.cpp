// Streaming fast search crosses document/query tiles without changing scores, ties or ownership.
#include "tieredq/tieredq.h"
#include "tieredq_scan_fast_scalar.h"
#include "tieredq_train_codebook_data.h"
#if defined(__x86_64__) && (defined(__GNUC__) || defined(__clang__))
#include "tieredq_scan_codes_x86.h"
#endif
#if defined(__aarch64__)
#include "tieredq_scan_codes_neon.h"
#endif
#include <algorithm>
#include <cmath>
#include <random>
#include <stdexcept>
#include <vector>
namespace {
void require(bool condition,const char* message) {
  if (!condition) throw std::runtime_error(message);
}
void high_bit_reference_test(uint32_t bits) {
  using namespace dv::tieredq_detail;
  constexpr size_t dimensions=13,documents=4109,training_rows=128,query_count=3;
  std::mt19937 random(123);std::normal_distribution<float> normal;
  std::vector<float> training(training_rows*dimensions),rows(documents*dimensions),queries(query_count*dimensions);
  for (auto& value:training) value=normal(random);
  for (auto& value:rows) value=normal(random);
  for (auto& value:queries) value=normal(random);
  auto codec=dv::TieredQ::train({dimensions,uint32_t(dimensions*bits),4,true},training.data(),training_rows);
  const auto encoded=codec.encode(rows.data(),documents);
  const auto books=gaussian_codebooks();
  const std::vector<std::vector<float>> levels(books.begin(),books.end());
  auto cache=build_fast_scan_cache(levels,codec.tiers(),codec.coded_dimensions(),documents,
      codec.bytes_per_vector(),codec.code_bytes(),4,fast_code_lookup_levels,encoded.data());
  dv::TieredQIndex index(codec,true);index.add(rows.data(),documents);
  for (size_t row=0;row<query_count;++row) {
    const auto q=codec.query(queries.data()+row*dimensions);
    std::vector<float> expected(documents),actual(documents);
    codec.score(encoded.data(),documents,q,expected.data(),dv::TieredQKernel::scalar);
    const auto prepared=fast_scan_query_scalar(*cache,codec,queries.data()+row*dimensions);
    scan_fast_scalar_tile(*cache,&prepared,1,0,documents,actual.data(),documents);
    require(actual==expected,"high-bit portable scan lost FP32 codebook precision");
#if defined(__x86_64__) && (defined(__GNUC__) || defined(__clang__))
    if (__builtin_cpu_supports("avx2")) {
      scan_codes_avx2(*cache,q,0,documents,actual.data());
      require(actual==expected,"high-bit AVX2 scan differs from scalar codec");
    }
    if (__builtin_cpu_supports("avx512f") && __builtin_cpu_supports("avx512bw")) {
      scan_codes_avx512(*cache,q,0,documents,actual.data());
      require(actual==expected,"high-bit AVX512 scan differs from scalar codec");
    }
#endif
#if defined(__aarch64__)
    scan_codes_neon(*cache,q,0,documents,actual.data());
    require(actual==expected,"high-bit NEON scan differs from scalar codec");
#endif
    std::vector<uint32_t> order(documents);
    std::iota(order.begin(),order.end(),0);
    std::sort(order.begin(),order.end(),[&](auto a,auto b){return expected[a]>expected[b] || (expected[a]==expected[b] && a<b);});
    const auto hits=index.search_fast(queries.data()+row*dimensions,10);
    for (size_t hit=0;hit<hits.size();++hit)
      require(hits[hit].id==order[hit] && hits[hit].score==expected[order[hit]],"high-bit native top-k differs from scalar codec");
  }
}
void streaming_search_test(uint32_t code_bits,uint32_t max_bits,bool fast_mode=false) {
  constexpr uint32_t dimensions=8,centroids=4;
  constexpr size_t training_rows=128,documents=4109,query_count=17;
  std::mt19937 random(17);
  std::normal_distribution<float> normal;
  std::vector<float> training(training_rows*dimensions),rows(documents*dimensions),queries(query_count*dimensions);
  for (auto& value:training) value=normal(random);
  for (auto& value:rows) value=normal(random);
  for (auto& value:queries) value=normal(random);
  std::fill_n(queries.data(),dimensions,0);
  for (size_t row=1;row<documents;row+=2) std::copy_n(rows.data(),dimensions,rows.data()+row*dimensions);
  auto codec=dv::TieredQ::train({dimensions,code_bits,centroids,false,max_bits},training.data(),training_rows);
  dv::TieredQIndex index(std::move(codec),fast_mode);
  index.add(rows.data(),documents);
  index.build_fast_scan();
  if (!index.has_fast_scan()) return;
  for (size_t k:{size_t(1),size_t(10),documents+1}) {
    const size_t found=std::min(k,documents);
    std::vector<float> scores(query_count*found);
    std::vector<uint32_t> ids(query_count*found);
    index.search_batch_fast(queries.data(),query_count,k,scores.data(),ids.data());
    for (size_t query=0;query<query_count;++query) {
      const auto hits=index.search_fast(queries.data()+query*dimensions,k);
      for (size_t hit=0;hit<found;++hit) {
        const size_t offset=query*found+hit;
        require(ids[offset]==hits[hit].id && scores[offset]==hits[hit].score,"streamed batch differs from single");
        if (!query) require(ids[offset]==hit,"zero-query ties do not retain lowest ids");
      }
    }
  }
}
} // namespace
void tieredq_search_tests() {
  high_bit_reference_test(7);high_bit_reference_test(8);
  streaming_search_test(16,4);
  streaming_search_test(64,8);
  streaming_search_test(16,4,true);
  streaming_search_test(64,8,true);
  streaming_search_test(56,8,true);
}
