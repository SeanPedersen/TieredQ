// NEON FP32 accumulation over byte code IDs preserves high-bit reconstruction levels.
#pragma once
#include "tieredq_scan_int8.h"
#include <arm_neon.h>

namespace dv::tieredq_detail {
inline void scan_codes_neon(const FastScanCache& cache,const TieredQQuery& q,
    size_t first,size_t count,float* scores) {
  constexpr size_t lanes=4;
  for (size_t doc=first;doc<first+count;doc+=lanes) {
    auto dot=vdupq_n_f32(0);
    const auto* base=cache.levels.data()+doc/fast_scan_block_docs*cache.groups*64+doc%fast_scan_block_docs*4;
    for (size_t rank=0;rank<cache.dimensions;++rank) {
      const auto packed=vreinterpretq_u32_s8(vld1q_s8(base+rank/4*64));
      const auto code=vandq_u32(vshlq_u32(packed,vdupq_n_s32(-int(rank%4*8))),vdupq_n_u32(UINT8_MAX));
      const auto* table=cache.codebooks[cache.tier_of[rank]].data();
      const float values[lanes]={table[vgetq_lane_u32(code,0)],table[vgetq_lane_u32(code,1)],
          table[vgetq_lane_u32(code,2)],table[vgetq_lane_u32(code,3)]};
      dot=vaddq_f32(dot,vmulq_f32(vld1q_f32(values),vdupq_n_f32(q.weights[rank])));
    }
    float centers[lanes],corrections[lanes];
    for (size_t lane=0;lane<lanes;++lane) {
      const auto cid=cache.centroid[doc+lane];
      centers[lane]=q.centroid_scores[cid];corrections[lane]=q.correction_weights[cid];
    }
    auto score=vaddq_f32(vld1q_f32(centers),vmulq_f32(vld1q_f32(corrections),vld1q_f32(cache.correction.data()+doc)));
    score=vaddq_f32(score,vmulq_f32(vld1q_f32(cache.factor.data()+doc),dot));
    float tail[lanes];vst1q_f32(tail,score);
    std::copy_n(tail,std::min(lanes,first+count-doc),scores+doc-first);
  }
}
} // namespace dv::tieredq_detail
