"""Fine-tier configuration of the flat index (#26, #31): option validation, default fine tiers, persistence."""
import numpy as np
import pytest
from tieredq import TieredQIndex

DIMENSIONS = 32
BITS_PER_DIM = 8
ROWS = 1024
QUERIES = 8
K = 10
DECAY = 0.85  # per-dimension spectrum decay steep enough that 8 bits/dim allocates codes past 8 bits
LLOYD_MAX_PREFIX_BITS = 8  # exact fast scores scan the 8-bit Lloyd-Max prefix of their fine tiers


def steep_rows(count, seed):
    rng = np.random.default_rng(seed)
    return (rng.normal(size=(count, DIMENSIONS)) * DECAY ** np.arange(DIMENSIONS)).astype(np.float32)


@pytest.mark.parametrize("value", ["auto", "on", "off"])
def test_fine_tiers_takes_a_bool(value):
    with pytest.raises(TypeError):
        TieredQIndex(DIMENSIONS, BITS_PER_DIM * DIMENSIONS, fine_tiers=value)


@pytest.mark.parametrize("options", [{"max_scan_bits": 9}, {"max_tier_bits": 13}, {"max_tier_bits": 0}])
def test_out_of_range_caps_are_rejected(options):
    with pytest.raises(RuntimeError):
        TieredQIndex(DIMENSIONS, BITS_PER_DIM * DIMENSIONS, **options)


def test_fine_tiers_search_and_round_trip(tmp_path):
    vectors, queries = steep_rows(ROWS, 26), steep_rows(QUERIES, 27)
    plain = TieredQIndex(DIMENSIONS, BITS_PER_DIM * DIMENSIONS, fine_tiers=False)
    fine = TieredQIndex(DIMENSIONS, BITS_PER_DIM * DIMENSIONS)
    plain.add(vectors)
    fine.add(vectors)
    assert fine.fast_prefix_bits == BITS_PER_DIM and plain.fast_prefix_bits == 0
    assert fine.bytes_per_vector == plain.bytes_per_vector
    scores, ids = fine.search(queries, K)
    assert ids.shape == (QUERIES, K) and np.all(np.diff(scores, axis=1) <= 0)
    path = str(tmp_path / "fine.tq")
    fine.save(path)
    loaded = TieredQIndex.load(path)
    assert loaded.fast_prefix_bits == BITS_PER_DIM
    for actual, reference in zip(loaded.search(queries, K), (scores, ids)):
        np.testing.assert_array_equal(actual, reference)


def test_full_mode_ignores_fine_tiers():
    index = TieredQIndex(DIMENSIONS, BITS_PER_DIM * DIMENSIONS, mode="full", fine_tiers=True)
    index.add(steep_rows(ROWS, 26))
    assert index.fast_prefix_bits == 0


def test_exact_fast_scores_use_lloyd_max_fine_tiers(tmp_path):
    vectors, queries = steep_rows(ROWS, 26), steep_rows(QUERIES, 27)
    exact = TieredQIndex(DIMENSIONS, BITS_PER_DIM * DIMENSIONS, exact_fast_scores=True)
    plain = TieredQIndex(DIMENSIONS, BITS_PER_DIM * DIMENSIONS, exact_fast_scores=True, fine_tiers=False)
    exact.add(vectors)
    plain.add(vectors)
    assert exact.fast_prefix_bits == LLOYD_MAX_PREFIX_BITS and plain.fast_prefix_bits == 0
    scores, ids = exact.search(queries, K)
    for row, query in enumerate(queries):
        single_scores, single_ids = exact.search(query[None, :], K)
        np.testing.assert_array_equal(single_ids[0], ids[row])
        np.testing.assert_array_equal(single_scores[0], scores[row])
    path = str(tmp_path / "exact-fine.tq")
    exact.save(path)
    loaded = TieredQIndex.load(path)
    assert loaded.fast_prefix_bits == LLOYD_MAX_PREFIX_BITS
    for actual, reference in zip(loaded.search(queries, K), (scores, ids)):
        np.testing.assert_array_equal(actual, reference)
