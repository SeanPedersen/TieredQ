"""Three figures and measured operating-point comparisons, without interpolation."""
import csv
import json
from pathlib import Path
import sys
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


def report(root):
    metadata = json.loads((root/"meta.json").read_text())
    if metadata.get("status") == "invalidated":
        raise ValueError("Refusing to report invalidated benchmark measurements")
    with (root/"results.csv").open() as handle:
        rows = list(csv.DictReader(handle))
    datasets = sorted({r["dataset"] for r in rows})
    figures = [("recall-storage", "effective_bytes_per_vector", "recall10"),
               ("qps-recall", "recall10", "qps"), ("latency-recall", "recall10", "p50_ms")]
    labels = {"effective_bytes_per_vector":"Effective bytes / vector", "recall10":"Recall@10",
              "qps":"Queries / second (batch 32)", "p50_ms":"Single-query latency (ms)"}
    for name, xkey, ykey in figures:
        fig, axes = plt.subplots(1, len(datasets), figsize=(6*len(datasets), 4), squeeze=False)
        for dataset, ax in zip(datasets, axes[0], strict=True):
            for codec in ("tieredq", "rabitq"):
                thread_counts = [1] if name == "recall-storage" else [1,8]
                for threads in thread_counts:
                    batch = 32 if name == "qps-recall" else 1
                    selected = [r for r in rows if r["dataset"]==dataset and r["codec"]==codec
                                and int(r["threads"])==threads and int(r["batch"])==batch]
                    if name != "recall-storage":
                        selected = [r for r in selected if int(r["seed"])==0]
                    groups = {}
                    for row in selected:
                        groups.setdefault(row["target_bits"], []).append(row)
                    points = sorted([(np.mean([float(r[xkey]) for r in group]),
                                      np.mean([float(r[ykey]) for r in group]),
                                      np.std([float(r[ykey]) for r in group]), group)
                                     for group in groups.values()], key=lambda p:p[0])
                    if not points:
                        continue
                    ax.errorbar([p[0] for p in points], [p[1] for p in points], yerr=[p[2] for p in points],
                                marker="o", label=f"{codec} {threads}t")
                    if name == "latency-recall":
                        ax.plot([p[0] for p in points], [float(p[3][0]["p95_ms"]) for p in points],
                                linestyle="--", label=f"{codec} {threads}t p95")
            ax.set(title=dataset, xlabel=labels[xkey], ylabel=labels[ykey])
            ax.grid(alpha=.2)
            ax.legend()
        fig.tight_layout()
        fig.savefig(root/f"{name}.png", dpi=160)
        plt.close(fig)
    from compare import operating_points, compare
    points = operating_points(rows)
    (root/"summary.json").write_text(json.dumps({"operating_points":points, "comparisons":compare(points)}, indent=2))

if __name__ == "__main__":
    report(Path(sys.argv[1]))
