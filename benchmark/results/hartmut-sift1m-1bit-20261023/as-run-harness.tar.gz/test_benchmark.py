"""Check metric transformations, chunked truth and complete-call timing contracts."""
import unittest
import numpy as np
from data import codec_vectors, ground_truth
from measure import measure


class BenchmarkTests(unittest.TestCase):
    def test_chunked_truth_matches_direct_l2_and_cosine(self):
        rng = np.random.default_rng(5)
        base = rng.normal(size=(16389, 6)).astype(np.float32)
        queries = rng.normal(size=(35, 6)).astype(np.float32)
        for l2 in (False, True):
            scores = queries @ base.T
            if l2:
                scores = -np.sum((queries[:, None] - base[None])**2, axis=2)
            expected = np.argsort(-scores, axis=1)[:, :10]
            np.testing.assert_array_equal(ground_truth(base, queries, l2), expected)

    def test_l2_lift_preserves_exact_rankings(self):
        rng = np.random.default_rng(7)
        base = rng.normal(size=(40, 8)).astype(np.float32)
        queries = rng.normal(size=(4, 8)).astype(np.float32)
        vectors, probes = codec_vectors(base, queries, True)
        np.testing.assert_array_equal(ground_truth(base, queries, True), ground_truth(vectors, probes, False))

    def test_batch_tail_and_recall(self):
        class Exact:
            def search(self, queries, output, threads):
                output[:] = np.arange(10)
        queries = np.ones((35, 2), dtype=np.float32)
        truth = np.tile(np.arange(10), (35, 1))
        result = measure(Exact(), queries, truth, 8, 32)
        self.assertEqual(result["recall10"], 1)
        self.assertGreater(result["qps"], 0)
        self.assertGreaterEqual(result["p95_ms"], result["p50_ms"])


if __name__ == "__main__":
    unittest.main()
